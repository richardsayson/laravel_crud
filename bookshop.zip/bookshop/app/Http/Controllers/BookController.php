<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;

class BookController extends Controller
{
    //
    public function viewbook(){
        $books = Book::all();
        return view('book.viewbook',['books' => $books]);
    }
    public function create(){
        return view('book.create');
    }
    public function store(Request $request){
        $data = $request->validate([
            'title' => 'required',
            'description' => 'required',
            'price' => 'required|decimal:0,2'
        ]);
        
        $newBook = Book::create($data);

        return redirect(route('book.viewbook'));
    }
    public function edit(Book $book){
        return view('book.edit',['book' => $book]);
    }
    public function update(Book $book, Request $request){
        $data = $request->validate([
            'title' => 'required',
            'description' => 'required',
            'price' => 'required|decimal:0,2'
        ]);
        $book->update($data);

        return redirect(route('book.viewbook'))->with('success', 'Book Updated');
    }
}
