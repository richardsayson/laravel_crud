<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BookShop</title>
</head>
<body>
    <h1>Book</h1>
    <div>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Book Title</th>
                <th>Description</th>
                <th>Price</th>
                <th>Edit</th>
            </tr>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($book->id); ?></td>
                <td><?php echo e($book->title); ?></td>
                <td><?php echo e($book->description); ?></td>
                <td><?php echo e($book->price); ?></td>
                <td>
                    <a href="<?php echo e(route('book.edit', ['book' => $book])); ?>">Edit</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    <div><Button>
    <a href="<?php echo e(route('book.create')); ?>">Add Book</a>    
    </Button></div>
</body>
</html><?php /**PATH C:\xampp_ni_gamay\htdocs\bookshop\resources\views/book/viewbook.blade.php ENDPATH**/ ?>